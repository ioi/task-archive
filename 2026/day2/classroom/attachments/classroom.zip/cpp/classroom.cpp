#include "classroom.h"

std::vector<std::vector<int>> process_step(int N, int M, int R, std::vector<int> T, std::vector<std::vector<int>> A) {
  std::vector<std::vector<int>> B = A;
  return B;
}

std::vector<int> determine_steps(int N, int M, std::vector<std::vector<int>> A) {
  std::vector<int> D(N, -1);
  return D;
}
