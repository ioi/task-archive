#include "magiccity.h"

std::pair<std::vector<int>, std::vector<std::pair<int, int>>> construct(int K) {
  std::vector<int> T;
  std::vector<std::pair<int, int>> E;
  return {T, E};
}
