#include "partition.h"

std::vector<int> add_numbers(std::vector<int> A, int K, int M) {
  return {1, 1, 2};
}

std::vector<int> find_partition(std::vector<int> B, int K) {
  int L = (int)B.size();
  return std::vector<int>(L, 0);
}
